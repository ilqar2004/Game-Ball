let bar = document.querySelector('.bar');
let ball = document.querySelector('.ball');
let score = document.querySelector('#player');

let barX = 0;
let ballX = 0;
let ballY = 0;
let dx = 5;
let dy = 5;
let point = 0;

let player = document.querySelector("#player");
let computer = document.querySelector("#computer");

// Random Color

let colors=["#FF0000","#FF0000","#FF0000","#FFFF00","#00FFFF","#FF00FF","#008080","#3498db","#95a5a6"];

// _______________________________________
document.onkeydown = barMove;

function barMove(e) {

    e = e || window.event;
    if (e.keyCode == "39") {
        if (barX < 0 || barX < 600) {
            barX += 25;
        }
    }


    if (e.keyCode == "37") {
        if (barX > 0) {
            barX -= 25;
        }
    }


    bar.style.left = barX + 'px';

}



setInterval(() => {
    if (ballX<0 || ballX>650) {
      dx *= -1;
    }


    if(ballY<0){
        dy *= -1;
    }
       
    else if(ballY>450 && ballX >= barX-25 && ballX <= barX +100){
    // Random color
        let rasgele=Math.floor(Math.random()*16777215).toString(16); 
        let rasgele2=Math.floor(Math.random()*colors.length); 
  
         document.querySelector(".ball").style.backgroundColor="#" + [rasgele]; 
         document.querySelector(".bar").style.backgroundColor=  colors[rasgele2];
    // _____________________________________________________________________
       point ++;
        score.innerHTML = `Point : ${point}`;
        dx++;
        dy++;
        dy *= -1;
    }  else if(ballY>450){
       document.body.innerHTML = 'Siz uduzdunuz :' + point;
    }




    ballX +=dx;
    ballY +=dy;

    ball.style.left = ballX + 'px';
    ball.style.top = ballY + 'px';



}, 40);

// function score() {
//     //player.innerHTML = '50';  

// }

// score();